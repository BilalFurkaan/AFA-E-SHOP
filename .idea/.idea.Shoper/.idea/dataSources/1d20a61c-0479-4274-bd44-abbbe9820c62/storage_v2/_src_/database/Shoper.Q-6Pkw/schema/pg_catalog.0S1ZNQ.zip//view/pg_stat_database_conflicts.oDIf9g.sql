create view pg_stat_database_conflicts
            (datid, datname, confl_tablespace, confl_lock, confl_snapshot, confl_bufferpin, confl_deadlock,
             confl_active_logicalslot)
as
SELECT oid                                           AS datid,
       datname,
       pg_stat_get_db_conflict_tablespace(oid)       AS confl_tablespace,
       pg_stat_get_db_conflict_lock(oid)             AS confl_lock,
       pg_stat_get_db_conflict_snapshot(oid)         AS confl_snapshot,
       pg_stat_get_db_conflict_bufferpin(oid)        AS confl_bufferpin,
       pg_stat_get_db_conflict_startup_deadlock(oid) AS confl_deadlock,
       pg_stat_get_db_conflict_logicalslot(oid)      AS confl_active_logicalslot
FROM pg_database d;

alter table pg_stat_database_conflicts
    owner to postgres;

grant select on pg_stat_database_conflicts to public;

